# Sparkle
Sparkle is a Selenium driven API for the MMORPG Freewar.

The available documentation can be found in [our wiki](https://github.com/ZabuzaW/Sparkle/wiki).
